﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RandomNumberFileWriter
{
    public partial class RandomNumberFileWriter : Form
    {
        public RandomNumberFileWriter()
        {
            InitializeComponent();
        }

        private void RandBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Declare int variable.
                int randNum = 0;

                // Declare a StreamWriter variable.
                StreamWriter outputFile;

                // Hold the amount of random numbers needed.
                int number = int.Parse(amntBox.Text);

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    // Create the selected file.
                    outputFile = File.CreateText(saveFileDialog.FileName);

                    // Create a Random.
                    Random Rand = new Random();

                    for (int count = 0; count < number; count++)
                    {
                        // Get random numbers and assign them to ranr.
                        randNum = Rand.Next(1, 101);

                        // Write data to the file.
                        outputFile.WriteLine(randNum);


                    }

                    // Close the file outside for loop
                    outputFile.Close();
                }
                else
                {
                    // Display an error message.
                    MessageBox.Show("Operation Cancelled");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


    private void exitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Clrbtn_Click(object sender, EventArgs e)
        {
            amntBox.Text = "";
        }
    }
}