﻿namespace RandomNumberFileWriter
{
    partial class RandomNumberFileWriter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.amntLbl = new System.Windows.Forms.Label();
            this.RandBtn = new System.Windows.Forms.Button();
            this.exitBtn = new System.Windows.Forms.Button();
            this.amntBox = new System.Windows.Forms.TextBox();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.Clrbtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // amntLbl
            // 
            this.amntLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.amntLbl.Location = new System.Drawing.Point(185, 9);
            this.amntLbl.Name = "amntLbl";
            this.amntLbl.Size = new System.Drawing.Size(369, 110);
            this.amntLbl.TabIndex = 0;
            this.amntLbl.Text = "Please Enter The Amount Of Random Numbers You Would Like";
            this.amntLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // RandBtn
            // 
            this.RandBtn.Location = new System.Drawing.Point(37, 200);
            this.RandBtn.Name = "RandBtn";
            this.RandBtn.Size = new System.Drawing.Size(120, 95);
            this.RandBtn.TabIndex = 1;
            this.RandBtn.Text = "Enter";
            this.RandBtn.UseVisualStyleBackColor = true;
            this.RandBtn.Click += new System.EventHandler(this.RandBtn_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.Location = new System.Drawing.Point(592, 200);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(120, 95);
            this.exitBtn.TabIndex = 2;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // amntBox
            // 
            this.amntBox.Location = new System.Drawing.Point(221, 122);
            this.amntBox.Name = "amntBox";
            this.amntBox.Size = new System.Drawing.Size(285, 26);
            this.amntBox.TabIndex = 3;
            // 
            // Clrbtn
            // 
            this.Clrbtn.Location = new System.Drawing.Point(315, 200);
            this.Clrbtn.Name = "Clrbtn";
            this.Clrbtn.Size = new System.Drawing.Size(120, 95);
            this.Clrbtn.TabIndex = 4;
            this.Clrbtn.Text = "Clear";
            this.Clrbtn.UseVisualStyleBackColor = true;
            this.Clrbtn.Click += new System.EventHandler(this.Clrbtn_Click);
            // 
            // RandomNumberFileWriter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(755, 307);
            this.Controls.Add(this.Clrbtn);
            this.Controls.Add(this.amntBox);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.RandBtn);
            this.Controls.Add(this.amntLbl);
            this.Name = "RandomNumberFileWriter";
            this.Text = "RandomNumberFileWriter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label amntLbl;
        private System.Windows.Forms.Button RandBtn;
        private System.Windows.Forms.Button exitBtn;
        private System.Windows.Forms.TextBox amntBox;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.Button Clrbtn;
    }
}

