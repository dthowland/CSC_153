﻿/**
* 02/18/18
* CSC 153
* David Edwards, David Howland, Aaron Williams
* This program will calculate the amount of revenue generated for selling seat tickets at a stadium
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ch3_G_PP14_Edwards
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Close the form for good.. Program is over.
            this.Close();
        }


        private void button2_Click(object sender, EventArgs e)
        {
            // Clearing out the input and output data so that we always have a clean start
            ticketBoxA.Text                = " ";
            ticketBoxB.Text                = " ";
            ticketBoxC.Text                = " ";
            totalTicketsLabel.Text         = " ";
            revenueALabel.Text             = " ";
            revenueBLabel.Text             = " ";
            revenueCLabel.Text             = " ";
            totalRevenueLabel.Text         = " ";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Declaring all of bthe variables to be used by the program
            double ticketsA;
            double ticketsB;
            double ticketsC;
            double totalTickets;
            double revenueA;
            double revenueB;
            double revenueC;
            double totalRevenue;

            // Getting the data from the user

            ticketsA = double.Parse(ticketBoxA.Text);
            ticketsB = double.Parse(ticketBoxB.Text);
            ticketsC = double.Parse(ticketBoxC.Text);
            totalTickets = ticketsA + ticketsB + ticketsC;
            totalTicketsLabel.Text = totalTickets.ToString("n");

            // Doing the necessary computations to be displayed later
            // The data captured will be properly formatted to facilitate reading 

            revenueA = ticketsA * 15;
            revenueALabel.Text = revenueA.ToString("c");
            revenueB = ticketsB * 12;
            revenueBLabel.Text = revenueB.ToString("c");
            revenueC = ticketsC * 9;
            revenueCLabel.Text = revenueC.ToString("c");

            // The following calculation is required to deytermine the total revenue
            // from all oof the tickets sold.
            totalRevenue = revenueA + revenueB + revenueC;
            totalRevenueLabel.Text = totalRevenue.ToString("c");


        }
       

    }
}
