﻿namespace Dice_Simulator1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.diceImageList1 = new System.Windows.Forms.ImageList(this.components);
            this.diceImageList2 = new System.Windows.Forms.ImageList(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.randomdiceButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // diceImageList1
            // 
            this.diceImageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("diceImageList1.ImageStream")));
            this.diceImageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.diceImageList1.Images.SetKeyName(0, "1Die.bmp");
            this.diceImageList1.Images.SetKeyName(1, "2Die.bmp");
            this.diceImageList1.Images.SetKeyName(2, "3Die.bmp");
            this.diceImageList1.Images.SetKeyName(3, "4Die.bmp");
            this.diceImageList1.Images.SetKeyName(4, "5Die.bmp");
            this.diceImageList1.Images.SetKeyName(5, "6Die.bmp");
            // 
            // diceImageList2
            // 
            this.diceImageList2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("diceImageList2.ImageStream")));
            this.diceImageList2.TransparentColor = System.Drawing.Color.Transparent;
            this.diceImageList2.Images.SetKeyName(0, "1Die.bmp");
            this.diceImageList2.Images.SetKeyName(1, "2Die.bmp");
            this.diceImageList2.Images.SetKeyName(2, "3Die.bmp");
            this.diceImageList2.Images.SetKeyName(3, "4Die.bmp");
            this.diceImageList2.Images.SetKeyName(4, "5Die.bmp");
            this.diceImageList2.Images.SetKeyName(5, "6Die.bmp");
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(59, 72);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 136);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(269, 72);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 136);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // randomdiceButton
            // 
            this.randomdiceButton.Location = new System.Drawing.Point(38, 328);
            this.randomdiceButton.Name = "randomdiceButton";
            this.randomdiceButton.Size = new System.Drawing.Size(131, 44);
            this.randomdiceButton.TabIndex = 2;
            this.randomdiceButton.Text = "Get Random Dice";
            this.randomdiceButton.UseVisualStyleBackColor = true;
            this.randomdiceButton.Click += new System.EventHandler(this.randomdiceButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(238, 328);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(131, 44);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(419, 416);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.randomdiceButton);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ImageList diceImageList1;
        private System.Windows.Forms.ImageList diceImageList2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button randomdiceButton;
        private System.Windows.Forms.Button exitButton;
    }
}

