﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dice_Simulator1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void randomdiceButton_Click(object sender, EventArgs e)
        {
            Random rand = new Random();

            int index1 = rand.Next(diceImageList1.Images.Count);
            int index2 = rand.Next(diceImageList2.Images.Count);

            pictureBox1.Image = diceImageList1.Images[index1];
            pictureBox2.Image = diceImageList2.Images[index2];

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();

        }
    }
}
