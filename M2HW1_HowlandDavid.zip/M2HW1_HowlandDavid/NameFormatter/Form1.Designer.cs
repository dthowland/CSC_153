﻿namespace NameFormatter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fnLabel = new System.Windows.Forms.Label();
            this.mnLabel = new System.Windows.Forms.Label();
            this.lnLabel = new System.Windows.Forms.Label();
            this.titleLabel = new System.Windows.Forms.Label();
            this.fnTextBox = new System.Windows.Forms.TextBox();
            this.mnTextBox = new System.Windows.Forms.TextBox();
            this.lnTextBox = new System.Windows.Forms.TextBox();
            this.titleTextBox = new System.Windows.Forms.TextBox();
            this.outputLabel = new System.Windows.Forms.Label();
            this.fmlButton = new System.Windows.Forms.Button();
            this.flButton = new System.Windows.Forms.Button();
            this.tfmlButton = new System.Windows.Forms.Button();
            this.lfmtButton = new System.Windows.Forms.Button();
            this.lfmButton = new System.Windows.Forms.Button();
            this.lfButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // fnLabel
            // 
            this.fnLabel.AutoSize = true;
            this.fnLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fnLabel.Location = new System.Drawing.Point(68, 97);
            this.fnLabel.Name = "fnLabel";
            this.fnLabel.Size = new System.Drawing.Size(76, 16);
            this.fnLabel.TabIndex = 0;
            this.fnLabel.Text = "First Name:";
            // 
            // mnLabel
            // 
            this.mnLabel.AutoSize = true;
            this.mnLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnLabel.Location = new System.Drawing.Point(68, 145);
            this.mnLabel.Name = "mnLabel";
            this.mnLabel.Size = new System.Drawing.Size(92, 16);
            this.mnLabel.TabIndex = 1;
            this.mnLabel.Text = "Middle Name:";
            // 
            // lnLabel
            // 
            this.lnLabel.AutoSize = true;
            this.lnLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnLabel.Location = new System.Drawing.Point(68, 190);
            this.lnLabel.Name = "lnLabel";
            this.lnLabel.Size = new System.Drawing.Size(76, 16);
            this.lnLabel.TabIndex = 2;
            this.lnLabel.Text = "Last Name:";
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.Location = new System.Drawing.Point(68, 233);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(37, 16);
            this.titleLabel.TabIndex = 3;
            this.titleLabel.Text = "Title:";
            // 
            // fnTextBox
            // 
            this.fnTextBox.Location = new System.Drawing.Point(211, 93);
            this.fnTextBox.Name = "fnTextBox";
            this.fnTextBox.Size = new System.Drawing.Size(161, 20);
            this.fnTextBox.TabIndex = 4;
            // 
            // mnTextBox
            // 
            this.mnTextBox.Location = new System.Drawing.Point(211, 141);
            this.mnTextBox.Name = "mnTextBox";
            this.mnTextBox.Size = new System.Drawing.Size(161, 20);
            this.mnTextBox.TabIndex = 5;
            // 
            // lnTextBox
            // 
            this.lnTextBox.Location = new System.Drawing.Point(211, 186);
            this.lnTextBox.Name = "lnTextBox";
            this.lnTextBox.Size = new System.Drawing.Size(161, 20);
            this.lnTextBox.TabIndex = 6;
            // 
            // titleTextBox
            // 
            this.titleTextBox.Location = new System.Drawing.Point(211, 229);
            this.titleTextBox.Name = "titleTextBox";
            this.titleTextBox.Size = new System.Drawing.Size(161, 20);
            this.titleTextBox.TabIndex = 7;
            // 
            // outputLabel
            // 
            this.outputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLabel.Location = new System.Drawing.Point(135, 378);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(346, 23);
            this.outputLabel.TabIndex = 8;
            this.outputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fmlButton
            // 
            this.fmlButton.Location = new System.Drawing.Point(12, 471);
            this.fmlButton.Name = "fmlButton";
            this.fmlButton.Size = new System.Drawing.Size(75, 23);
            this.fmlButton.TabIndex = 9;
            this.fmlButton.Text = "F,M,L";
            this.fmlButton.UseVisualStyleBackColor = true;
            this.fmlButton.Click += new System.EventHandler(this.fmlButton_Click);
            // 
            // flButton
            // 
            this.flButton.Location = new System.Drawing.Point(111, 471);
            this.flButton.Name = "flButton";
            this.flButton.Size = new System.Drawing.Size(75, 23);
            this.flButton.TabIndex = 10;
            this.flButton.Text = "F,L";
            this.flButton.UseVisualStyleBackColor = true;
            this.flButton.Click += new System.EventHandler(this.flButton_Click);
            // 
            // tfmlButton
            // 
            this.tfmlButton.Location = new System.Drawing.Point(211, 471);
            this.tfmlButton.Name = "tfmlButton";
            this.tfmlButton.Size = new System.Drawing.Size(75, 23);
            this.tfmlButton.TabIndex = 11;
            this.tfmlButton.Text = "T,F,M,L";
            this.tfmlButton.UseVisualStyleBackColor = true;
            this.tfmlButton.Click += new System.EventHandler(this.tfmlButton_Click);
            // 
            // lfmtButton
            // 
            this.lfmtButton.Location = new System.Drawing.Point(322, 471);
            this.lfmtButton.Name = "lfmtButton";
            this.lfmtButton.Size = new System.Drawing.Size(75, 23);
            this.lfmtButton.TabIndex = 12;
            this.lfmtButton.Text = "L,F,M,T";
            this.lfmtButton.UseVisualStyleBackColor = true;
            this.lfmtButton.Click += new System.EventHandler(this.lfmtButton_Click);
            // 
            // lfmButton
            // 
            this.lfmButton.Location = new System.Drawing.Point(428, 471);
            this.lfmButton.Name = "lfmButton";
            this.lfmButton.Size = new System.Drawing.Size(75, 23);
            this.lfmButton.TabIndex = 13;
            this.lfmButton.Text = "L,F,M";
            this.lfmButton.UseVisualStyleBackColor = true;
            this.lfmButton.Click += new System.EventHandler(this.lfmButton_Click);
            // 
            // lfButton
            // 
            this.lfButton.Location = new System.Drawing.Point(536, 471);
            this.lfButton.Name = "lfButton";
            this.lfButton.Size = new System.Drawing.Size(75, 23);
            this.lfButton.TabIndex = 14;
            this.lfButton.Text = "L,F";
            this.lfButton.UseVisualStyleBackColor = true;
            this.lfButton.Click += new System.EventHandler(this.lfButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(510, 300);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 15;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(510, 338);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 16;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(634, 506);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.lfButton);
            this.Controls.Add(this.lfmButton);
            this.Controls.Add(this.lfmtButton);
            this.Controls.Add(this.tfmlButton);
            this.Controls.Add(this.flButton);
            this.Controls.Add(this.fmlButton);
            this.Controls.Add(this.outputLabel);
            this.Controls.Add(this.titleTextBox);
            this.Controls.Add(this.lnTextBox);
            this.Controls.Add(this.mnTextBox);
            this.Controls.Add(this.fnTextBox);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.lnLabel);
            this.Controls.Add(this.mnLabel);
            this.Controls.Add(this.fnLabel);
            this.Name = "Form1";
            this.Text = "Name Formatter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label fnLabel;
        private System.Windows.Forms.Label mnLabel;
        private System.Windows.Forms.Label lnLabel;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.TextBox fnTextBox;
        private System.Windows.Forms.TextBox mnTextBox;
        private System.Windows.Forms.TextBox lnTextBox;
        private System.Windows.Forms.TextBox titleTextBox;
        private System.Windows.Forms.Label outputLabel;
        private System.Windows.Forms.Button fmlButton;
        private System.Windows.Forms.Button flButton;
        private System.Windows.Forms.Button tfmlButton;
        private System.Windows.Forms.Button lfmtButton;
        private System.Windows.Forms.Button lfmButton;
        private System.Windows.Forms.Button lfButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button clearButton;
    }
}

