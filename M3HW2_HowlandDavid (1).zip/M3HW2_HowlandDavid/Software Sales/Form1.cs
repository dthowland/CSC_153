﻿/**
 * 02/07/18
 * CSC 153
 * David Howland
 * Software Sales Assignment
 * */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Software_Sales
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void tButton_Click(object sender, EventArgs e)
        {
            //Variable to hold the quantity.
            double quantity;
            double decdiscount;
            double decdiscount1;
            double decdiscount2;
            double decdiscount3;
            double retail;
            double subtotal;
            double total;
            double ttotal;
           

            //Get the quantity.
            quantity = double.Parse(quantityTextBox.Text);
            //Declare variables
            retail = 99;
            decdiscount = .2;
            decdiscount1 = .3;
            decdiscount2 = .4;
            decdiscount3 = .5;
           
            
            //Determine if a discount is given.
            if (quantity < 9)
            {

                disLabel.Text = "No Discount";
                subtotal = (quantity * retail);
                totalLabel.Text = subtotal.ToString("c");

            }
            else
            {
                if (quantity < 19)
                {
                    disLabel.Text = "20%";
                    subtotal = (quantity * retail);
                    ttotal = subtotal * decdiscount;
                    total = subtotal - ttotal;
                    totalLabel.Text = total.ToString("c");
                    
                }
                else
                {
                    if (quantity < 49)
                    {
                        disLabel.Text = "30%";
                        subtotal = (quantity * retail);
                        ttotal = subtotal * decdiscount1;
                        total = subtotal - ttotal;
                        totalLabel.Text = total.ToString("c");

                    }
                    else
                    {
                        if (quantity < 99)
                        {
                            disLabel.Text = "40%";
                            subtotal = (quantity * retail);
                            ttotal = subtotal * decdiscount2;
                            total = subtotal - ttotal;
                            totalLabel.Text = total.ToString("c");

                        }
                        else
                        {
                            disLabel.Text = "50%";
                            subtotal = (quantity * retail);
                            ttotal = subtotal * decdiscount3;
                            total = subtotal - ttotal;
                            totalLabel.Text = total.ToString("c");

                        }

                    }
                    }
                }
            }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void eButton_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();

        }
    }
    }

