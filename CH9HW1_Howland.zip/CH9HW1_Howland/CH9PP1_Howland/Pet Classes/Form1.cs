﻿/**
 * 05/14/18
 * CSC 153
 * David Howland 
 * Pet Classes
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pet_Classes
{
    public partial class Pet : Form
    {
        protected new String Name;
        protected String Type;
        protected int Age;
        public Pet()
        {
            InitializeComponent();
        }
        private void GetPetObjectData(Pet petObject)
        {
            petObject.Name = nameTextBox.Text;
            petObject.Type = typeTextBox.Text;
            if (Int32.TryParse(ageTextBox.Text, out int age))
            {
                petObject.Age = age;
            }
            else
                MessageBox.Show("Invalid age");

        }

        private void DisplayButton_Click(object sender, EventArgs e)
        {
            Pet petObject = new Pet();
            GetPetObjectData(petObject);
            nameLabel.Text = petObject.Name;
            tyepLabel.Text = petObject.Type;
#pragma warning disable CS1690 // Accessing a member on a field of a marshal-by-reference class may cause a runtime exception
            ageLabel.Text = petObject.Age.ToString("0");
#pragma warning restore CS1690 // Accessing a member on a field of a marshal-by-reference class may cause a runtime exception
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
