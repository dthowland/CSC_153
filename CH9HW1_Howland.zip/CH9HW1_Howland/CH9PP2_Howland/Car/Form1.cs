﻿/**
 * 05/13/18
 * CSC 153
 * David Howland
 * Car Project
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car
{
    public partial class Form1 : Form
    {
        Car car = new Car();
        public Form1()
        {
            InitializeComponent();
        }

        private void accelerateButton_Click(object sender, EventArgs e)
        {
            if (makeTxtBox.Text == String.Empty || yearTxtBox.Text == String.Empty)
                MessageBox.Show("Make and Year are empty");
            else
            {
                car.Accelerate();
                label3.Text = Convert.ToString(car.getSpeed());
            }
        }

        private void brakeButton_Click(object sender, EventArgs e)
        {
            if (makeTxtBox.Text == String.Empty || yearTxtBox.Text == String.Empty)
                MessageBox.Show("Make and Year are empty");
            else
            {
                if (car.getSpeed() > 0)
                    car.Brake();
                else
                    MessageBox.Show("Speed cannot be negative", "Error");

                label3.Text = Convert.ToString(car.getSpeed());
            }
        }

        private void makeTxtBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
