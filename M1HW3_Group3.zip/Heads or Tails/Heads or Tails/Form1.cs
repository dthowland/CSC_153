﻿/**
* 31 January 2018
* CSC 153
* Group 3
* A program that displays a side of a coin to the user
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Heads_or_Tails
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void showHeadsButton_Click(object sender, EventArgs e)
        {
            //Show heads when selected
            showHeadsPictureBox.Visible = true;
            showTailsPictureBox.Visible = false;
        }

        private void showTailsButton_Click(object sender, EventArgs e)
        {
            //Show tails when selected
            showHeadsPictureBox.Visible = false;
            showTailsPictureBox.Visible = true;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close and exit the program
            this.Close();
        }
    }
}
