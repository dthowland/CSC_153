﻿namespace Heads_or_Tails
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.showHeadsButton = new System.Windows.Forms.Button();
            this.showTailsButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.showHeadsPictureBox = new System.Windows.Forms.PictureBox();
            this.showTailsPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.showHeadsPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.showTailsPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // showHeadsButton
            // 
            this.showHeadsButton.Location = new System.Drawing.Point(86, 253);
            this.showHeadsButton.Name = "showHeadsButton";
            this.showHeadsButton.Size = new System.Drawing.Size(120, 72);
            this.showHeadsButton.TabIndex = 0;
            this.showHeadsButton.Text = "Show Heads";
            this.showHeadsButton.UseVisualStyleBackColor = true;
            this.showHeadsButton.Click += new System.EventHandler(this.showHeadsButton_Click);
            // 
            // showTailsButton
            // 
            this.showTailsButton.Location = new System.Drawing.Point(278, 253);
            this.showTailsButton.Name = "showTailsButton";
            this.showTailsButton.Size = new System.Drawing.Size(120, 72);
            this.showTailsButton.TabIndex = 1;
            this.showTailsButton.Text = "Show Tails";
            this.showTailsButton.UseVisualStyleBackColor = true;
            this.showTailsButton.Click += new System.EventHandler(this.showTailsButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(458, 253);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(120, 72);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // showHeadsPictureBox
            // 
            this.showHeadsPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("showHeadsPictureBox.Image")));
            this.showHeadsPictureBox.Location = new System.Drawing.Point(46, 53);
            this.showHeadsPictureBox.Name = "showHeadsPictureBox";
            this.showHeadsPictureBox.Size = new System.Drawing.Size(187, 157);
            this.showHeadsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.showHeadsPictureBox.TabIndex = 3;
            this.showHeadsPictureBox.TabStop = false;
            this.showHeadsPictureBox.Visible = false;
            // 
            // showTailsPictureBox
            // 
            this.showTailsPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("showTailsPictureBox.Image")));
            this.showTailsPictureBox.Location = new System.Drawing.Point(278, 53);
            this.showTailsPictureBox.Name = "showTailsPictureBox";
            this.showTailsPictureBox.Size = new System.Drawing.Size(177, 157);
            this.showTailsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.showTailsPictureBox.TabIndex = 4;
            this.showTailsPictureBox.TabStop = false;
            this.showTailsPictureBox.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(604, 358);
            this.Controls.Add(this.showTailsPictureBox);
            this.Controls.Add(this.showHeadsPictureBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.showTailsButton);
            this.Controls.Add(this.showHeadsButton);
            this.Name = "Form1";
            this.Text = "Heads or Tails";
            ((System.ComponentModel.ISupportInitialize)(this.showHeadsPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.showTailsPictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button showHeadsButton;
        private System.Windows.Forms.Button showTailsButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.PictureBox showHeadsPictureBox;
        private System.Windows.Forms.PictureBox showTailsPictureBox;
    }
}

