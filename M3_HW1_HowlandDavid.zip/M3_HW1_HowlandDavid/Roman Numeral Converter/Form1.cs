﻿/**
 * 03/10/18
 * CSC 153
 * David Howland
 * Roman Numeral Converter
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Roman_Numeral_Converter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            double number;


            //Enter a number to convert 
            number = int.Parse(inputTextBox.Text);

            if (number == 1)
            {
                resultLabel.Text = ("I");
            }
            else if (number == 2)
            {
                resultLabel.Text = ("II");

            }
            else if (number == 3)
            {
                resultLabel.Text = ("III");

            }
            else if (number == 4)
            {
                resultLabel.Text = ("IV");
            }
            else if (number == 5)
            {
                resultLabel.Text = ("V");
            }
            else if (number == 6)
            {
                resultLabel.Text = ("VI");
            }
            else if (number == 7)
            {
                resultLabel.Text = ("VII");
            }
            else if (number == 8)
            {
                resultLabel.Text = ("VIII");
            }
            else if (number == 9)
            {
                resultLabel.Text = ("IX");
            }
            else if (number == 10)
            {
                resultLabel.Text = ("X");
            }
        }
    }
}