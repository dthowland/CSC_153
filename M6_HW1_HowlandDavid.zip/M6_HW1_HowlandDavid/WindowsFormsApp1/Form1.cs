﻿/**
 * 04/26/18 
 * CSC 153
 * David Howland
 * Falling Distance
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            


        }

        private void button1_Click(object sender, EventArgs e)
        {
            double time, value;
            time = double.Parse(tTextbox.Text);

            value = FallingDistance(time);

            MessageBox.Show("Distance of the object is:" + value + "m/sec");
        }
                private double FallingDistance(double time)
                {
                return 0.5 * 9.8 * (time * time);
                }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
