﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sentence_Builder_01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private string output;

        private void aaaButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text += output + "A";
        }

        private void aaButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text += output + "a";
        }

        private void aButton_Click(object sender, EventArgs e)
        {

            outputLabel.Text += output + "An";
        }

        private void anButton_Click(object sender, EventArgs e)
        {

            outputLabel.Text += output + "an";
        }

        private void tButton_Click(object sender, EventArgs e)
        {

            outputLabel.Text += output + "The";
        }

        private void theButton_Click(object sender, EventArgs e)
        {

            outputLabel.Text += output + "the";
        }

        private void manButton_Click(object sender, EventArgs e)
        {

            outputLabel.Text += output + "man";
        }

        private void womanButton_Click(object sender, EventArgs e)
        {

            outputLabel.Text += output + "woman";
        }

        private void catButton_Click(object sender, EventArgs e)
        {

            outputLabel.Text += output + "dog";
        }

        private void carButton_Click(object sender, EventArgs e)
        {

            outputLabel.Text += output + "car";
        }

        private void bicycleButton_Click(object sender, EventArgs e)
        {

            outputLabel.Text += output + "bicycle";
        }

        private void beautifulButton_Click(object sender, EventArgs e)
        {

            outputLabel.Text += output + "beautiful";
        }

        private void bigButton_Click(object sender, EventArgs e)
        {

            outputLabel.Text += output + "big";
        }

        private void smallButton_Click(object sender, EventArgs e)
        {

            outputLabel.Text += output + "small";
        }

        private void strangeButton_Click(object sender, EventArgs e)
        {

            outputLabel.Text += output + "strange";
        }

        private void lookedButton_Click(object sender, EventArgs e)
        {

            outputLabel.Text += output + "looked at";
        }

        private void rodeButton_Click(object sender, EventArgs e)
        {

            outputLabel.Text += output + "rode";
        }

        private void spokeButton_Click(object sender, EventArgs e)
        {

            outputLabel.Text += output + "spoke to";
        }

        private void laughedButton_Click(object sender, EventArgs e)
        {

            outputLabel.Text += output + "laughed at";
        }

        private void droveButton_Click(object sender, EventArgs e)
        {

            outputLabel.Text += output + "drove";
        }

        private void spaceButton_Click(object sender, EventArgs e)
        {

            outputLabel.Text += output + " ";
        }

        private void periodButton_Click(object sender, EventArgs e)
        {

            outputLabel.Text += output + ".";
        }

        private void exclamationButton_Click(object sender, EventArgs e)
        {

            outputLabel.Text += output + "!";
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
