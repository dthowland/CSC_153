﻿namespace Sentence_Builder_01
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.aaaButton = new System.Windows.Forms.Button();
            this.aaButton = new System.Windows.Forms.Button();
            this.aButton = new System.Windows.Forms.Button();
            this.anButton = new System.Windows.Forms.Button();
            this.tButton = new System.Windows.Forms.Button();
            this.theButton = new System.Windows.Forms.Button();
            this.manButton = new System.Windows.Forms.Button();
            this.womanButton = new System.Windows.Forms.Button();
            this.catButton = new System.Windows.Forms.Button();
            this.carButton = new System.Windows.Forms.Button();
            this.bicycleButton = new System.Windows.Forms.Button();
            this.beautifulButton = new System.Windows.Forms.Button();
            this.bigButton = new System.Windows.Forms.Button();
            this.smallButton = new System.Windows.Forms.Button();
            this.strangeButton = new System.Windows.Forms.Button();
            this.lookedButton = new System.Windows.Forms.Button();
            this.rodeButton = new System.Windows.Forms.Button();
            this.spokeButton = new System.Windows.Forms.Button();
            this.laughedButton = new System.Windows.Forms.Button();
            this.droveButton = new System.Windows.Forms.Button();
            this.spaceButton = new System.Windows.Forms.Button();
            this.periodButton = new System.Windows.Forms.Button();
            this.exclamationButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.outputLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // aaaButton
            // 
            this.aaaButton.Location = new System.Drawing.Point(128, 24);
            this.aaaButton.Name = "aaaButton";
            this.aaaButton.Size = new System.Drawing.Size(85, 47);
            this.aaaButton.TabIndex = 1;
            this.aaaButton.Text = "A";
            this.aaaButton.UseVisualStyleBackColor = true;
            this.aaaButton.Click += new System.EventHandler(this.aaaButton_Click);
            // 
            // aaButton
            // 
            this.aaButton.Location = new System.Drawing.Point(232, 24);
            this.aaButton.Name = "aaButton";
            this.aaButton.Size = new System.Drawing.Size(75, 47);
            this.aaButton.TabIndex = 2;
            this.aaButton.Text = "a";
            this.aaButton.UseVisualStyleBackColor = true;
            this.aaButton.Click += new System.EventHandler(this.aaButton_Click);
            // 
            // aButton
            // 
            this.aButton.Location = new System.Drawing.Point(332, 24);
            this.aButton.Name = "aButton";
            this.aButton.Size = new System.Drawing.Size(107, 47);
            this.aButton.TabIndex = 3;
            this.aButton.Text = "An";
            this.aButton.UseVisualStyleBackColor = true;
            this.aButton.Click += new System.EventHandler(this.aButton_Click);
            // 
            // anButton
            // 
            this.anButton.Location = new System.Drawing.Point(466, 24);
            this.anButton.Name = "anButton";
            this.anButton.Size = new System.Drawing.Size(75, 47);
            this.anButton.TabIndex = 4;
            this.anButton.Text = "an";
            this.anButton.UseVisualStyleBackColor = true;
            this.anButton.Click += new System.EventHandler(this.anButton_Click);
            // 
            // tButton
            // 
            this.tButton.Location = new System.Drawing.Point(556, 24);
            this.tButton.Name = "tButton";
            this.tButton.Size = new System.Drawing.Size(81, 47);
            this.tButton.TabIndex = 5;
            this.tButton.Text = "The";
            this.tButton.UseVisualStyleBackColor = true;
            this.tButton.Click += new System.EventHandler(this.tButton_Click);
            // 
            // theButton
            // 
            this.theButton.Location = new System.Drawing.Point(64, 91);
            this.theButton.Name = "theButton";
            this.theButton.Size = new System.Drawing.Size(83, 47);
            this.theButton.TabIndex = 6;
            this.theButton.Text = "the";
            this.theButton.UseVisualStyleBackColor = true;
            this.theButton.Click += new System.EventHandler(this.theButton_Click);
            // 
            // manButton
            // 
            this.manButton.Location = new System.Drawing.Point(166, 91);
            this.manButton.Name = "manButton";
            this.manButton.Size = new System.Drawing.Size(91, 47);
            this.manButton.TabIndex = 7;
            this.manButton.Text = "man ";
            this.manButton.UseVisualStyleBackColor = true;
            this.manButton.Click += new System.EventHandler(this.manButton_Click);
            // 
            // womanButton
            // 
            this.womanButton.Location = new System.Drawing.Point(272, 91);
            this.womanButton.Name = "womanButton";
            this.womanButton.Size = new System.Drawing.Size(91, 47);
            this.womanButton.TabIndex = 8;
            this.womanButton.Text = "woman ";
            this.womanButton.UseVisualStyleBackColor = true;
            this.womanButton.Click += new System.EventHandler(this.womanButton_Click);
            // 
            // catButton
            // 
            this.catButton.Location = new System.Drawing.Point(384, 91);
            this.catButton.Name = "catButton";
            this.catButton.Size = new System.Drawing.Size(77, 47);
            this.catButton.TabIndex = 9;
            this.catButton.Text = "dog";
            this.catButton.UseVisualStyleBackColor = true;
            this.catButton.Click += new System.EventHandler(this.catButton_Click);
            // 
            // carButton
            // 
            this.carButton.Location = new System.Drawing.Point(484, 91);
            this.carButton.Name = "carButton";
            this.carButton.Size = new System.Drawing.Size(97, 47);
            this.carButton.TabIndex = 10;
            this.carButton.Text = "car";
            this.carButton.UseVisualStyleBackColor = true;
            this.carButton.Click += new System.EventHandler(this.carButton_Click);
            // 
            // bicycleButton
            // 
            this.bicycleButton.Location = new System.Drawing.Point(604, 91);
            this.bicycleButton.Name = "bicycleButton";
            this.bicycleButton.Size = new System.Drawing.Size(99, 47);
            this.bicycleButton.TabIndex = 11;
            this.bicycleButton.Text = "bicycle";
            this.bicycleButton.UseVisualStyleBackColor = true;
            this.bicycleButton.Click += new System.EventHandler(this.bicycleButton_Click);
            // 
            // beautifulButton
            // 
            this.beautifulButton.Location = new System.Drawing.Point(146, 151);
            this.beautifulButton.Name = "beautifulButton";
            this.beautifulButton.Size = new System.Drawing.Size(111, 47);
            this.beautifulButton.TabIndex = 12;
            this.beautifulButton.Text = "beautiful ";
            this.beautifulButton.UseVisualStyleBackColor = true;
            this.beautifulButton.Click += new System.EventHandler(this.beautifulButton_Click);
            // 
            // bigButton
            // 
            this.bigButton.Location = new System.Drawing.Point(280, 151);
            this.bigButton.Name = "bigButton";
            this.bigButton.Size = new System.Drawing.Size(93, 47);
            this.bigButton.TabIndex = 13;
            this.bigButton.Text = "big";
            this.bigButton.UseVisualStyleBackColor = true;
            this.bigButton.Click += new System.EventHandler(this.bigButton_Click);
            // 
            // smallButton
            // 
            this.smallButton.Location = new System.Drawing.Point(392, 151);
            this.smallButton.Name = "smallButton";
            this.smallButton.Size = new System.Drawing.Size(105, 47);
            this.smallButton.TabIndex = 14;
            this.smallButton.Text = "small";
            this.smallButton.UseVisualStyleBackColor = true;
            this.smallButton.Click += new System.EventHandler(this.smallButton_Click);
            // 
            // strangeButton
            // 
            this.strangeButton.Location = new System.Drawing.Point(520, 151);
            this.strangeButton.Name = "strangeButton";
            this.strangeButton.Size = new System.Drawing.Size(99, 47);
            this.strangeButton.TabIndex = 15;
            this.strangeButton.Text = "strange ";
            this.strangeButton.UseVisualStyleBackColor = true;
            this.strangeButton.Click += new System.EventHandler(this.strangeButton_Click);
            // 
            // lookedButton
            // 
            this.lookedButton.Location = new System.Drawing.Point(34, 214);
            this.lookedButton.Name = "lookedButton";
            this.lookedButton.Size = new System.Drawing.Size(113, 47);
            this.lookedButton.TabIndex = 16;
            this.lookedButton.Text = "looked at ";
            this.lookedButton.UseVisualStyleBackColor = true;
            this.lookedButton.Click += new System.EventHandler(this.lookedButton_Click);
            // 
            // rodeButton
            // 
            this.rodeButton.Location = new System.Drawing.Point(171, 214);
            this.rodeButton.Name = "rodeButton";
            this.rodeButton.Size = new System.Drawing.Size(115, 47);
            this.rodeButton.TabIndex = 17;
            this.rodeButton.Text = "rode";
            this.rodeButton.UseVisualStyleBackColor = true;
            this.rodeButton.Click += new System.EventHandler(this.rodeButton_Click);
            // 
            // spokeButton
            // 
            this.spokeButton.Location = new System.Drawing.Point(308, 214);
            this.spokeButton.Name = "spokeButton";
            this.spokeButton.Size = new System.Drawing.Size(121, 47);
            this.spokeButton.TabIndex = 18;
            this.spokeButton.Text = "spoke to ";
            this.spokeButton.UseVisualStyleBackColor = true;
            this.spokeButton.Click += new System.EventHandler(this.spokeButton_Click);
            // 
            // laughedButton
            // 
            this.laughedButton.Location = new System.Drawing.Point(446, 214);
            this.laughedButton.Name = "laughedButton";
            this.laughedButton.Size = new System.Drawing.Size(155, 47);
            this.laughedButton.TabIndex = 19;
            this.laughedButton.Text = "laughed at ";
            this.laughedButton.UseVisualStyleBackColor = true;
            this.laughedButton.Click += new System.EventHandler(this.laughedButton_Click);
            // 
            // droveButton
            // 
            this.droveButton.Location = new System.Drawing.Point(618, 214);
            this.droveButton.Name = "droveButton";
            this.droveButton.Size = new System.Drawing.Size(107, 47);
            this.droveButton.TabIndex = 20;
            this.droveButton.Text = "drove";
            this.droveButton.UseVisualStyleBackColor = true;
            this.droveButton.Click += new System.EventHandler(this.droveButton_Click);
            // 
            // spaceButton
            // 
            this.spaceButton.Location = new System.Drawing.Point(232, 272);
            this.spaceButton.Name = "spaceButton";
            this.spaceButton.Size = new System.Drawing.Size(121, 47);
            this.spaceButton.TabIndex = 21;
            this.spaceButton.Text = "(Space)";
            this.spaceButton.UseVisualStyleBackColor = true;
            this.spaceButton.Click += new System.EventHandler(this.spaceButton_Click);
            // 
            // periodButton
            // 
            this.periodButton.Location = new System.Drawing.Point(374, 272);
            this.periodButton.Name = "periodButton";
            this.periodButton.Size = new System.Drawing.Size(55, 47);
            this.periodButton.TabIndex = 22;
            this.periodButton.Text = ".";
            this.periodButton.UseVisualStyleBackColor = true;
            this.periodButton.Click += new System.EventHandler(this.periodButton_Click);
            // 
            // exclamationButton
            // 
            this.exclamationButton.Location = new System.Drawing.Point(446, 272);
            this.exclamationButton.Name = "exclamationButton";
            this.exclamationButton.Size = new System.Drawing.Size(55, 47);
            this.exclamationButton.TabIndex = 23;
            this.exclamationButton.Text = "!";
            this.exclamationButton.UseVisualStyleBackColor = true;
            this.exclamationButton.Click += new System.EventHandler(this.exclamationButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(216, 424);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(137, 47);
            this.clearButton.TabIndex = 24;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(392, 424);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(137, 47);
            this.exitButton.TabIndex = 25;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // outputLabel
            // 
            this.outputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLabel.Location = new System.Drawing.Point(46, 352);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(669, 51);
            this.outputLabel.TabIndex = 26;
            this.outputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(756, 483);
            this.Controls.Add(this.outputLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.exclamationButton);
            this.Controls.Add(this.periodButton);
            this.Controls.Add(this.spaceButton);
            this.Controls.Add(this.droveButton);
            this.Controls.Add(this.laughedButton);
            this.Controls.Add(this.spokeButton);
            this.Controls.Add(this.rodeButton);
            this.Controls.Add(this.lookedButton);
            this.Controls.Add(this.strangeButton);
            this.Controls.Add(this.smallButton);
            this.Controls.Add(this.bigButton);
            this.Controls.Add(this.beautifulButton);
            this.Controls.Add(this.bicycleButton);
            this.Controls.Add(this.carButton);
            this.Controls.Add(this.catButton);
            this.Controls.Add(this.womanButton);
            this.Controls.Add(this.manButton);
            this.Controls.Add(this.theButton);
            this.Controls.Add(this.tButton);
            this.Controls.Add(this.anButton);
            this.Controls.Add(this.aButton);
            this.Controls.Add(this.aaButton);
            this.Controls.Add(this.aaaButton);
            this.Name = "Form1";
            this.Text = "Sentence Builder";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button aaaButton;
        private System.Windows.Forms.Button aaButton;
        private System.Windows.Forms.Button aButton;
        private System.Windows.Forms.Button anButton;
        private System.Windows.Forms.Button tButton;
        private System.Windows.Forms.Button theButton;
        private System.Windows.Forms.Button manButton;
        private System.Windows.Forms.Button womanButton;
        private System.Windows.Forms.Button catButton;
        private System.Windows.Forms.Button carButton;
        private System.Windows.Forms.Button bicycleButton;
        private System.Windows.Forms.Button beautifulButton;
        private System.Windows.Forms.Button bigButton;
        private System.Windows.Forms.Button smallButton;
        private System.Windows.Forms.Button strangeButton;
        private System.Windows.Forms.Button lookedButton;
        private System.Windows.Forms.Button rodeButton;
        private System.Windows.Forms.Button spokeButton;
        private System.Windows.Forms.Button laughedButton;
        private System.Windows.Forms.Button droveButton;
        private System.Windows.Forms.Button spaceButton;
        private System.Windows.Forms.Button periodButton;
        private System.Windows.Forms.Button exclamationButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label outputLabel;
    }
}

